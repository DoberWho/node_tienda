const model = require("./categoria.model")

exports.get = async function (req, res, next) {

    const body = req.body;
    const query = req.query;
    const params = req.params;
  
    console.log("BODY: "+body);
    
    let code = 200 
    return res.status(code).json(body);
}

exports.post = async function (req, res, next) {

    const body = req.body;
    const query = req.query;
    const params = req.params; 
 
    let obj = new model()
    obj.name = body.name
    obj = await obj.save()
    
    let code = 200 
    return res.status(code).json(obj);
}

exports.detail = async function (req, res, next) {

    const body = req.body;
    const query = req.query;
    const params = req.params; 

    
    console.log("BODY: "+body);
    
    let code = 200 
    return res.status(code).json(body);
}

exports.delete = async function (req, res, next) {

    const body = req.body;
    const query = req.query;
    const params = req.params; 

    
    console.log("BODY: "+body);
    
    let code = 200 
    return res.status(code).json(body);
}