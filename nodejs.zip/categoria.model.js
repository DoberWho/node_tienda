'use strict';
let mongoose = require('mongoose'); 
let Schema = mongoose.Schema;

const opts = {
    name: {
      type: String,
      lowercase:true,
      trim:true
    },
}
const params = { timestamps: true }
let Category = new Schema(opts, params);

module.exports = mongoose.model('category', Category);